#include <iostream>
#include <string>

std::string getString( std::istream& is, std::ostream& os, const std::string& prompt ) {
    os << prompt;
    std::string FavColor;
    is >> FavColor;
    return FavColor;
}

int getInteger( std::istream& is, std::ostream& os, const std::string& prompt ) {
    os << prompt;
    int FavNum;
    is >> FavNum;
    return FavNum;
}

double getDouble( std::istream& is, std::ostream& os, const std::string& prompt ) {
    os << prompt;
    double FavFloat;
    is >> FavFloat;
    return FavFloat;
}

int assignment1( std::istream& is, std::ostream& os ) {
    std::string prompt1 ("What is your favorite Color?");
    std::string prompt2 ("What is your favorite whole number?");
    std::string prompt3 ("What is your favorite decimal number?");
    std::string FavString = getString(is, os, prompt1);
    int FavInt = getInteger(is, os, prompt2);
    double FFloat = getDouble(is, os, prompt3);

    int i;
    for (i=0; i < FavInt; i++) {
        std::cout << i+1 << " " << FavString << " " << FFloat << std::endl;
    }
    return 0;
}
