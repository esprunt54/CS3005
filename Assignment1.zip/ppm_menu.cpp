#include <iostream>
#include "image_menu.h"

int main() {
    assignment1(std::cin, std::cout);
    return 0;
}